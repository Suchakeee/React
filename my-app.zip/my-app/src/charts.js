export default function Charts() {

    return (
        <>
        <div class="flip-card-front">
        <div className="one">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H1</h1>
            <div className="pie animate"> 100%</div>
        </div>
        <div className="two">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H2</h1>
            <div className="pie animate"> 100%</div>
            </div>
        <div className="three">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H3</h1>
            <div className="pie animate"> 100%</div>
            </div>
        </div>
        <div class="flip-card-back">
        <div className="one">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H4</h1>
            <div className="pie animate"> 100%</div>
        </div>
        <div className="two">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H5</h1>
            <div className="pie animate"> 100%</div>
        </div>
        <div className="three">
            <i className="gg-thermometer"></i>
            <h1 style={{padding:'5%'}}>H6</h1>
            <div className="pie animate"> 100%</div>
        </div>
        </div>
        </>

    );
}