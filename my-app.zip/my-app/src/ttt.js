
export default function ttt () {
    const x = 4 + 5;
    return (x)

    


}




